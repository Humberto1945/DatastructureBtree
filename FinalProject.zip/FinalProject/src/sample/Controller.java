package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;
import javax.swing.*;

import java.io.IOException;

public class Controller {
   public RadioButton yellowRad;
    public RadioButton shirtRad;
    public RadioButton dressRad;
    public RadioButton pantsRad;
    public RadioButton mediumRad;
    public RadioButton sRAd;
    public RadioButton lRad;
    public RadioButton blueRad;
    public RadioButton pinkRad;
    public RadioButton redRad;


    // This method changes the scene
    public void searchScreenButtonPushed(ActionEvent event) throws IOException {
        Parent tableViewParent= FXMLLoader.load(getClass().getResource("search.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        //This line gets the Stage information
        Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }
    public void setUpScreenButtonPushed(ActionEvent event) throws IOException{
        Parent tableViewParent= FXMLLoader.load(getClass().getResource("setUp.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        //This line gets the Stage information
        Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }
    public void deleteScreenButtonPushed(ActionEvent event)throws IOException{
        Parent tableViewParent= FXMLLoader.load(getClass().getResource("delete.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        //This line gets the Stage information
        Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }

    public void searchButton(ActionEvent event){

    }
    //Exits the program
    public void exitButtonClicked(ActionEvent event){
        System.exit(0);
    }

    public void restButtonClicked(ActionEvent event){
        yellowRad.setSelected(false);
        shirtRad.setSelected(false);
        dressRad.setSelected(false);
        pantsRad.setSelected(false);
        mediumRad.setSelected(false);
        sRAd.setSelected(false);
        lRad.setSelected(false);
        blueRad.setSelected(false);
        pinkRad.setSelected(false);
        redRad.setSelected(false);
    }
    public void colorIsPicked(ActionEvent event) {
        if (yellowRad.isSelected()) {
            blueRad.setSelected(false);
            redRad.setSelected(false);
            pinkRad.setSelected(false);
        } else if (blueRad.isSelected()) {
            redRad.setSelected(false);
            pinkRad.setSelected(false);
            yellowRad.setSelected(false);
        } else if (redRad.isSelected()) {
            pinkRad.setSelected(false);
            yellowRad.setSelected(false);
            blueRad.setSelected(false);
        } else if (pinkRad.isSelected()) {
            yellowRad.setSelected(false);
            blueRad.setSelected(false);
            redRad.setSelected(false);

        }
    }//end of color is picked
        public void clothesIsPicked(ActionEvent event){
            if(shirtRad.isSelected()){
                dressRad.setSelected(false);
                pantsRad.setSelected(false);
            }else if(dressRad.isSelected()){
                pantsRad.setSelected(false);
                shirtRad.setSelected(false);
            }else if(pantsRad.isSelected()){
                shirtRad.setSelected(false);
                dressRad.setSelected(false);
            }

        }//end of clothes is picked

    public void sizeIsPicked(ActionEvent event){
        if(sRAd.isSelected()){
            lRad.setSelected(false);
            mediumRad.setSelected(false);
        }else if(lRad.isSelected()){
            mediumRad.setSelected(false);
            sRAd.setSelected(false);
        }else if(mediumRad.isSelected()){
            lRad.setSelected(false);
            sRAd.setSelected(false);
        }
    }//end of size is picked









}//end of controller class


