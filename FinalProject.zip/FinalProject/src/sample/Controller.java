package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;
import javax.swing.*;

import java.io.IOException;

public class Controller extends Main {
   public   RadioButton yellowRad;
    public  RadioButton shirtRad;
    public  RadioButton dressRad;
    public  RadioButton pantsRad;
    public  RadioButton mediumRad;
    public  RadioButton sRAd;
    public  RadioButton lRad;
    public  RadioButton blueRad;
    public  RadioButton pinkRad;
    public  RadioButton redRad;
   public  static Btree bTree = new Btree(3);
    public  static String b1="";
    public  static String b2="";
    public  static String b3="";


    // This method changes the scene
    public void searchScreenButtonPushed(ActionEvent event) throws IOException {
        Parent tableViewParent= FXMLLoader.load(getClass().getResource("search.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        //This line gets the Stage information
        Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }
    public void setUpScreenButtonPushed(ActionEvent event) throws IOException{
        Parent tableViewParent= FXMLLoader.load(getClass().getResource("setUp.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        //This line gets the Stage information
        Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }
    public void deleteScreenButtonPushed(ActionEvent event)throws IOException{
        Parent tableViewParent= FXMLLoader.load(getClass().getResource("delete.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        //This line gets the Stage information
        Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }


    public void setUpInventoryButton(ActionEvent event){
        barcodeMethod();
        String finalBarcode = b1 + b2+b3 ;
        int barcode=Integer.parseInt(finalBarcode);
        bTree.Insert(barcode);
        System.out.println("This is what is in the inventory");
        bTree.Show();

    }
    public void searchInventoryButton(ActionEvent event){
        barcodeMethod();
        String finalBarcode = b1 + b2+b3 ;
        int barcode=Integer.parseInt(finalBarcode);
        bTree.Search(barcode);
        if (bTree.Search(barcode)) {
            System.out.println("\nfound");
        } else {
            System.out.println("\nThese are not availble.Here are some optiopns you could pick");
            bTree.Show();
        }

    }
    public void deleteInventoryButton(ActionEvent event) {
        barcodeMethod();
        String finalBarcode = b1 + b2+b3 ;
        int barcode=Integer.parseInt(finalBarcode);
        bTree.Delete(barcode);
        bTree.Show();
        System.out.println("This is what is left");
        bTree.Show();

    }



    public void barcodeMethod(){
        if(dressRad.isSelected()){
            b1= Integer.toString(1);

        }
        else if(shirtRad.isSelected()){
            b1= Integer.toString(2);

        }
        else if( pantsRad.isSelected()){
            b1= Integer.toString(3);

        }
        if(yellowRad.isSelected()){
            b2= Integer.toString(4);
        }
        else if(blueRad.isSelected()){
            b2 = Integer.toString(5);
        }
        else if( redRad.isSelected()){
            b2= Integer.toString(6);

        }
        if(mediumRad.isSelected()){
            b3= Integer.toString(7);
        }
        else if(sRAd.isSelected()){
            b3= Integer.toString(8);
        }
        else if(lRad.isSelected()){
            b3= Integer.toString(9);

        }
    }

    //Exits the program
    public void exitButtonClicked(ActionEvent event){
        System.exit(0);
    }

    public void restButtonClicked(ActionEvent event){
        yellowRad.setSelected(false);
        shirtRad.setSelected(false);
        dressRad.setSelected(false);
        pantsRad.setSelected(false);
        mediumRad.setSelected(false);
        sRAd.setSelected(false);
        lRad.setSelected(false);
        blueRad.setSelected(false);
        pinkRad.setSelected(false);
        redRad.setSelected(false);
    }
    public void colorIsPicked(ActionEvent event) {
        if (yellowRad.isSelected()) {
            blueRad.setSelected(true);
            redRad.setSelected(true);
            pinkRad.setSelected(true);
        } else if (blueRad.isSelected()) {
            redRad.setSelected(true);
            pinkRad.setSelected(true);
            yellowRad.setSelected(true);
        } else if (redRad.isSelected()) {
            pinkRad.setSelected(true);
            yellowRad.setSelected(true);
            blueRad.setSelected(true);
        } else if (pinkRad.isSelected()) {
            yellowRad.setSelected(true);
            blueRad.setSelected(true);
            redRad.setSelected(true);

        }
    }//end of color is picked

       public void clothesIsPicked(ActionEvent event){
            if(shirtRad.isSelected()){
                dressRad.setSelected(false);
                pantsRad.setSelected(false);
            }else if(dressRad.isSelected()){
                pantsRad.setSelected(false);
                shirtRad.setSelected(false);
            }else if(pantsRad.isSelected()){
                shirtRad.setSelected(false);
                dressRad.setSelected(false);
            }

        }//end of clothes is picked



    public void sizeIsPicked(ActionEvent event){
        if(sRAd.isSelected()){
            lRad.setSelected(true);
            mediumRad.setSelected(true);
        }else if(lRad.isSelected()){
            mediumRad.setSelected(true);
            sRAd.setSelected(true);
        }else if(mediumRad.isSelected()){
            lRad.setSelected(true);
            sRAd.setSelected(true);
        }


    }//end of size is picked


    public void backToHome(ActionEvent event) throws IOException {
        Parent tableViewParent= FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        //This line gets the Stage information
        Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();


    }


}//end of controller class


